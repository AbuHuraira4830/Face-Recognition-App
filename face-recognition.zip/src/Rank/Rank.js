import React from 'react';
import "./rank.css";

const Rank = ({name,entries}) => {
  return (
    <div>
        <div className='white f2 mtc'>
            {`${name} your current entry count is ...`}
        </div>
        <div className='white f1 mt2'>
            {entries}
        </div>
    </div>
  )
}

export default Rank;